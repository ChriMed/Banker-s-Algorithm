This project covers the banker algorithm for measuring the safety of processes.
this algorithm takes information from a text files storing them into 2D vectors.
This program will...
	Echo the number of processes.
	Echo the number of resource types.
	Echo the allocation matrix.  Label the processes and resource types 
	Echo the max matrix.  Label the processes and resource types 
	Compute and print the need matrix.  Label the processes and resource types 
	Echo the available vector.  Label the resource types.
	Compute if the system is in a safe state.
	Echo the request vector.  Label the process making the request and resource types. 
	Compute if the request can be granted.
	Compute the new available vector.
Following this the program will compute the safety of the system using the he bankers algorithm with functions addprocess and safestate. After all processes are considered, the result of the test will be displayed.